@echo off
rem OpenClaw Gateway (v2026.2.24)
set "TMPDIR=C:\Users\NITIN_~1\AppData\Local\Temp"
set "PATH=C:\WINDOWS\system32;C:\WINDOWS;C:\WINDOWS\System32\Wbem;C:\WINDOWS\System32\WindowsPowerShell\v1.0\;C:\WINDOWS\System32\OpenSSH\;C:\Program Files\MySQL\MySQL Server 8.0\bin;C:\Program Files\HP\HP One Agent;C:\Users\nitin_2n4diox\AppData\Local\Programs\Python\Python313;C:\Program Files\Git\cmd;C:\Program Files\nodejs\;C:\Users\nitin_2n4diox\AppData\Local\Programs\Python\Python313\Scripts\;C:\Program Files\MySQL\MySQL Shell 8.0\bin\;C:\Users\nitin_2n4diox\AppData\Local\Microsoft\WindowsApps;C:\Users\nitin_2n4diox\AppData\Local\Programs\Microsoft VS Code\bin;C:\Users\nitin_2n4diox\AppData\Local\pip;C:\Users\nitin_2n4diox\AppData\Local\Programs\Antigravity\bin;C:\Users\nitin_2n4diox\AppData\Roaming\npm"
set "OPENCLAW_GATEWAY_PORT=18789"
set "OPENCLAW_GATEWAY_TOKEN=3407ba42a1e510fe032968f2cecea0f0a0d271677dc5b811"
set "OPENCLAW_SYSTEMD_UNIT=openclaw-gateway.service"
set "OPENCLAW_SERVICE_MARKER=openclaw"
set "OPENCLAW_SERVICE_KIND=gateway"
set "OPENCLAW_SERVICE_VERSION=2026.2.24"
"C:\Program Files\nodejs\node.exe" C:\Users\nitin_2n4diox\AppData\Roaming\npm\node_modules\openclaw\dist\index.js gateway --port 18789
